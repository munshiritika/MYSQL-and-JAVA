package ThothIt_WebSQL;
//02-02-2024, Friday

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class InsertionMultiple {
	public static void main(String[] args) {
		try {
			//step 1: Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver is loaded.");
			
			//step 2: Create the connection
 			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/thothitweb_db","root","root");
			System.out.println("Connection has been created");
			
			//step 3: Fire the query
			String insertquery = "insert into signup_tbl(username, password, email, gender) values(?, ?, ?, ?)";
			PreparedStatement pstatement = connection.prepareStatement(insertquery);
			
			//Multiple record to insert
			String[] username = {"Sushan", "Kaya", "Maya", "Chaya", "Sandeep"};
			String[] password = {"sushan123", "kaya123", "maya123", "chaya123", "sandeep123"};
			String[] email = {"sushan@gmail.com", "kaya@gmail.com", "maya@gmail.com", "chaya@gmail.com", "sandeep@gmail.com"};
			String[] gender = {"Male", "Female", "Female", "Female", "Male"};
			
			//Inserting multiple records
			int j = 0;
			for(int i = 0; i < username.length; i++) {
				pstatement.setString(1, username[i]);
				pstatement.setString(2, password[i]);
				pstatement.setString(3, email[i]);
				pstatement.setString(4, gender[i]);
				j = pstatement.executeUpdate();
			}
			
			if(j > 0) {
				System.out.println("Records have been inserted.");
			}
			else {
				System.out.println("Records have not been inserted.");
			}
		}//try
			
		catch(Exception e) {
			e.printStackTrace();
		}//catch

	}
}
