package ThothIt_WebSQL;
//02-02-2024, Friday

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SelectionParticularRow {

	public static void main(String[] args) {
		try {
			//step 1: Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver is loaded.");
			
			//step 2: Create the connection
 			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/thothitweb_db","root","root");
			System.out.println("Connection has been created");
			
			//step 3: Fire the query
			String insertquery = "select * from signup_tbl where id = ?";  //we can also do select * from signup_tbl where id = 1 and not have pstatement.setInt(1, 1)
			PreparedStatement pstatement = connection.prepareStatement(insertquery); //PreparedStatement is used to execute parameterized query
			pstatement.setInt(1, 1); //index number , value we want to get
			
			
			ResultSet resultSet = pstatement.executeQuery();
			while(resultSet.next()) {
				System.out.println(resultSet.getInt(1) + " " + resultSet.getString(2) + " " + resultSet.getString(3) + " " + resultSet.getString(4) + " " + resultSet.getString(5));
			}			
		}//try
			
		catch(Exception e) {
			e.printStackTrace();
		}//catch

	}
}
