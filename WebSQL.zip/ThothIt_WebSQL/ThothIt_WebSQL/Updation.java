package ThothIt_WebSQL;
//02-01-2024, Thursday

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Updation {

	public static void main(String[] args) {
		try {
			//step 1: Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver is loaded.");
			
			//step 2: Create the connection
 			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/thothitweb_db","root","root");
			System.out.println("Connection has been created");
			
			//step 3: Fire the query
			String insertquery = "update signup_tbl set username = 'Astrid' where id = 5";
			PreparedStatement pstatement = connection.prepareStatement(insertquery);
			
			int i = pstatement.executeUpdate();
			if(i > 0) {
				System.out.println("Record has been updated.");
			}
			else {
				System.out.println("Record has not been updated.");
			}
		}//try
			
		catch(Exception e) {
			e.printStackTrace();
		}//catch

	}

}
