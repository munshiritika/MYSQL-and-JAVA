package ThothIt_WebSQL;
//02-01-2024, Thursday

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Deletion {

	public static void main(String[] args) {
		try {
			//step 1: Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver is loaded.");
			
			//step 2: Create the connection
 			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/thothitweb_db","root","root");
			System.out.println("Connection has been created");
			
			//step 3: Fire the query
			String insertquery = "delete from signup_tbl where id = ?";
			PreparedStatement pstatement = connection.prepareStatement(insertquery);
			pstatement.setInt(1, 17);  //setInt because deletion is based on index
			
			int i = pstatement.executeUpdate();
			if(i > 0) {
				System.out.println("Record has been deleted.");
			}
			else {
				System.out.println("Record has not been deleted.");
			}
		}//try
			
		catch(Exception e) {
			e.printStackTrace();
		}//catch


	}

}
