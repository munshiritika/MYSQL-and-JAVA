package ThothIt_WebSQL;
//01-31-2024, Wednesday

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Insertion {

	public static void main(String[] args) {
		try {
			//step 1: Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver is loaded.");
			
			//step 2: Create the connection
 			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/thothitweb_db","root","root");
			System.out.println("Connection has been created");
			
			//step 3: Fire the query
			String insertquery = "insert into signup_tbl(username, password, email, gender) values(?, ?, ?, ?)";
			PreparedStatement pstatement = connection.prepareStatement(insertquery);
			pstatement.setString(1, "Alekh");
			pstatement.setString(2, "alekh123");
			pstatement.setString(3, "alekh@gmail.com");
			pstatement.setString(4, "Male");
			
			int i = pstatement.executeUpdate();
			if(i > 0) {
				System.out.println("Record has been inserted.");
			}
			else {
				System.out.println("Record has not been inserted.");
			}
		}//try
			
		catch(Exception e) {
			e.printStackTrace();
		}//catch

	}
}

