package ThothIt_WebSQL;
//02-01-2024, Thursday

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SelectionAllData {
//Result Set is a pointer to the row
//Checks if there is another record or not
//if there is another record then it will print that
	
	public static void main(String[] args) {
		try {
			//step 1: Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver is loaded.");
			
			//step 2: Create the connection
 			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/thothitweb_db","root","root");
			System.out.println("Connection has been created");
			
			//step 3: Fire the query
			String insertquery = "select * from signup_tbl";
			PreparedStatement pstatement = connection.prepareStatement(insertquery);
			
			ResultSet resultSet = pstatement.executeQuery();
			while(resultSet.next()) {
				System.out.println(resultSet.getInt(1) + " " + resultSet.getString(2) + " " + resultSet.getString(3) + " " + resultSet.getString(4) + " " + resultSet.getString(5));
			}			
		}//try
			
		catch(Exception e) {
			e.printStackTrace();
		}//catch

	}
}
